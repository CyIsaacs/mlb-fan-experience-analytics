# PSTAT Final Notebook Data Sources

This zip contains the processed CSV files required to run `pstat_final.ipynb`.
Unzip it from the project root so the files land under `data/processed/`.

Included files:

- `data/processed/final_project_team_game_999_optimality_2024_2026.csv`
  - Main team-game panel used for the 9/9/9 index.
- `data/processed/final_project_source_notes.csv`
  - Dataset source notes and caveats.
- `data/processed/final_project_validation_summary_2024_2026.csv`
  - Validation summary for the processed panel.
- `data/processed/final_project_concessions_2024_2026.csv`
  - Team-season beer, hot dog, and 9/9/9 concession cost data.
- `data/processed/final_project_player_star_scores_2024_2026.csv`
  - Player performance/accolade scores used for the superstar factor.
- `data/processed/final_project_2024_normalization_parameters.csv`
  - 2024 baseline normalization parameters.
- `data/processed/final_project_bullpen_staleness_model_results.csv`
  - Late-game staleness model comparison results.
- `data/processed/final_project_pregame_auc_backtest_2025.csv`
  - 2025 pre-game holdout/AUC results.
